import React from "react";
import { Container, Row, Col } from "react-bootstrap";
import { useState } from 'react';

function Home2() {
  const [imageUrls1, setImageUrls1] = useState([]);
  const [imageUrls2, setImageUrls2] = useState([]);

  const handleFileSelect = (event) => {
    const id = event.target.id;
    const files = event.target.files;
    const newImageUrls = [];

    for (const file of files) {
      newImageUrls.push(URL.createObjectURL(file));
    }

    if (id === 'input1') {
      setImageUrls1(newImageUrls);
    } else if (id === 'input2') {
      setImageUrls2(newImageUrls);
    }
  };

  return (
    <Container fluid className="home-about-section" id="about">
      <Container>
        <Row>
          <Col md={12} className="home-about-social">
            <h1>Insert Image/s of Self</h1>
            <p>
              <input type="file" multiple id="input1" onChange={handleFileSelect} />
              {imageUrls1.map((url, index) => (
                <img key={index} src={url} alt="Selected Image 1" style={{ width: '50%', height: '50%' }} />
              ))}
            </p>
            <p>
            <h1>Insert Image/s of Clothes</h1>
            <input type="file" multiple id="input2" onChange={handleFileSelect} />
            {imageUrls2.map((url, index) => (
              <img key={index} src={url} alt="Selected Image 2" style={{ width: '50%', height: '50%' }} />
            ))}
            </p>
          </Col>
        </Row>
      </Container>
    </Container>
  );
}
export default Home2;
