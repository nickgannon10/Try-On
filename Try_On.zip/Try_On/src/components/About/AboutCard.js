import React from "react";
import Card from "react-bootstrap/Card";
import { ImPointRight } from "react-icons/im";

function AboutCard() {
  return (
    <Card className="quote-card-view">
      <Card.Body>
        <blockquote className="blockquote mb-0">
          <p style={{ textAlign: "justify" }}>
            Hi Everyone, we are<span className="purple"> NJG and Neoptim, </span>
            and we both <span className="purple"> like Andrej Karpathy </span>
            <br /> 
            <br /> Stuff about us. 
            <br />
            <br />
            Why we built this!
          </p>
          <ul>
            <li className="about-activity">
              <ImPointRight /> We have faces 
            </li>
            <li className="about-activity">
              <ImPointRight /> We wear clothes 
            </li>
            <li className="about-activity">
              <ImPointRight /> We build stuff
            </li>
          </ul>
        </blockquote>
      </Card.Body>
    </Card>
  );
}

export default AboutCard;
